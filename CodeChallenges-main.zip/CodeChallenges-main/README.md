# CodeChallenges

This is a .Net Core 3.1 Console application.

It is designed to test your ability to create C# unit tests. 

The application itself has been built with flaws to test your ability to cover both handled and unhandled exceptions.

Make use of which ever testing framework you are comfortable with. Be sure to measure your coverage.

Please fork this repo and send us a public link for review once you feel you have completed the required tasks.

Good luck!
