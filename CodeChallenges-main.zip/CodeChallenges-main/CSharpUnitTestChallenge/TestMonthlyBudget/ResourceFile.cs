﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestMonthlyBudget
{
    public class ResourceFile
    {
        public const string inValidFirstName= "S";
        public const string validFirstName = "Shailender";

        public const string inValidLastName = "I";
        public const string validLastName = "Singh";

        public const string inValidDOB = "SSSS";
        public const string lessInvalidDOB = "08/11/2020";
        public const string validDOB = "08/11/1987";

        public const string inValidPetFoodCost = "10S";
        public const string validPetFoodCost = "50";

        public const string inValidNumberOFPets = "5S";
        public const string validNumberPets = "5";
    }
}
